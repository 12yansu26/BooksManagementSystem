package book.vo;
/**
 * 
 * @author Administrator
 *�û���
 *�û�����
 *�û�Ȩ��
 */
public class User {
	private String name;
	private String password;
	private int card;
	public int getCard() {
		return card;
	}
	public void setCard(int card) {
		this.card = card;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
}
