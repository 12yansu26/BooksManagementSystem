package book.vo;
/**
 * 
 * @author Administrator
 *������
 *�������ǳ�
 *ͼ����
 */
public class Record {
	private String card;
	private String username;
	private String book_id;
	public String getBook_id() {
		return book_id;
	}
	public void setBook_id(String book_id) {
		this.book_id = book_id;
	}
	public String getCard() {
		return card;
	}
	public void setCard(String card) {
		this.card = card;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	
	
}
