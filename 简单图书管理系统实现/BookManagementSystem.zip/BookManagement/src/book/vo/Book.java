package book.vo;
/**
 * 
 * @author ͼ����
 * ͼ������
 * ͼ������
 * ͼ����
 *
 */
public class Book {
	private String bookid;
	private String bookname;
	private String author;
	private int booknumber;

	public String getBookid(){
		return bookid;
	}
	public void setBookid( String bookid){
		this.bookid = bookid;
	}
	public String getBookName(){
		return bookname;
	}

	public void setBookName(String bookname){	
		this.bookname = bookname;
	}
	public String getBookAuthor(){
		return author;
	}
	public void setBookAuthor(String Author){
		this.author = Author;
	}
	public int getBookNumber(){
		return booknumber;
	}

	public void setBookNumber(int booknumber){
		this.booknumber = booknumber;
	}

}
