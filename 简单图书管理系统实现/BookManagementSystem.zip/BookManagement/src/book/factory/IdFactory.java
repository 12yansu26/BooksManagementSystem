package book.factory;

import java.util.Random;
/**
 * 
 * ���ɽ�����
 *
 */
public class IdFactory {
	public static String getId(){
		char a[]={'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z'};
		String text="";
		Random r= new Random();
		for(int i = 0;i<10;i++){
			text+=a[(int)r.nextInt(26)];
		}
		return text;
	}
}
