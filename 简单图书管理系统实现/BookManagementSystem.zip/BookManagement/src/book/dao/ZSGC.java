package book.dao;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import book.jdbc.JDBCGet;
import book.vo.Book;
import book.vo.Record;
import book.vo.User;
public class ZSGC {
	Connection conn = null;
	Statement stmt = null;
	ResultSet rs = null;
	//ʵ��ͼ������
	public boolean Zeng(Book book){ 
		try{
			//ͨ��JDBCGet���ȡ���� ��> Connection
			conn = JDBCGet.getconn();
			//ͨ��Connection��ȡStatement���� -��stmt
			stmt = conn.createStatement();
			//��д���ݿ�������
			String sql = "insert into book (id,name,author,num)values"
			+ "('"+book.getBookid()+"','"+book.getBookName()+"','"+book.getBookAuthor()+"','"+book.getBookNumber()+"')";
			//�������ݿ���� ��ȡ����״���
			int num = stmt.executeUpdate(sql);
			//�ͷ���Դ
			JDBCGet.closek(conn, stmt, rs);
			//�ж��Ƿ�����ɹ�
			if(num > 0){
				return true;
			}
			return false;
		}catch(Exception e){
			e.printStackTrace();
		}
		return false;
	}
	
	//ע�� �����û�
	public boolean Zeng(User user){ 
		try{
			conn = JDBCGet.getconn();
			stmt = conn.createStatement();
			String sql = "insert into user (grade,name,password)values"
			+ "("+user.getCard()+",'"+user.getName()+"','"+user.getPassword()+"')";
			int num = stmt.executeUpdate(sql);
			JDBCGet.closek(conn, stmt, rs);
			if(num > 0){
				return true;
			}
			return false;
		}catch(Exception e){
			e.printStackTrace();
		}
		return false;
	}
	
	//���ӽ�����Ϣ
	public boolean Zeng(Record record){ 
		try{
			conn = JDBCGet.getconn();
			stmt = conn.createStatement();
			String sql = "insert into record (card,username,book_id)values"
			+ "('"+record.getCard()+"','"+record.getUsername()+"','"+record.getBook_id()+"')";
			int num = stmt.executeUpdate(sql);
			JDBCGet.closek(conn, stmt, rs);
			if(num > 0){
				return true;
			}
			return false;
		}catch(Exception e){
			e.printStackTrace();
		}
		return false;
	}
	//����Աɾ���鼮������ͼ��ID��
	public boolean Shan(String id){
		try{
			conn = JDBCGet.getconn();
			stmt = conn.createStatement();
			String sql = "delete from book where id= '"+id+"'";
			int num = stmt.executeUpdate(sql);
			JDBCGet.closek(conn, stmt, rs);
			if(num > 0)
			{
				return true;
			}
			return false;
		}catch(Exception e){
			e.printStackTrace();
		}
		return false;
	}
	//ɾ��������Ϣ
	public boolean Shan(Record record){
		try{
			conn = JDBCGet.getconn();
			stmt = conn.createStatement();
			String sql = "delete from record where card='"+record.getCard()+"'";
			int num = stmt.executeUpdate(sql);
			JDBCGet.closek(conn, stmt, rs);
			if(num > 0)
			{
				return true;
			}
			return false;
		}catch(Exception e){
			e.printStackTrace();
		}
		return false;
	}
	//����Ա����������ͨ����ţ�
	public boolean Gai(String id,String name){ 
		try{
			conn = JDBCGet.getconn();
			stmt = conn.createStatement();
			String sql = "update book set name ='"+name+"' where id ='"+id+"'";
			int s = stmt.executeUpdate(sql);
			JDBCGet.closek(conn, stmt, rs);
			if(s > 0)
			{
				return true;
			}
			return false;
		}catch(Exception e){
			e.printStackTrace();
		}
		return false;
	}
	//�������������顢���飩
	public boolean Gai(int num,String a){ 
		try{
			conn = JDBCGet.getconn();
			stmt = conn.createStatement();
			String sql = "update book set num ="+num+" where id ='"+a+"'";
			int s = stmt.executeUpdate(sql);
			JDBCGet.closek(conn, stmt, rs);
			if(s > 0)
			{
				return true;
			}
			return false;
		}catch(Exception e){
			e.printStackTrace();
		}
		return false;
	}
	//��ѯ�û���Ϣ��������¼�ж�����)
	public User login(String name){ 
		try{
			conn = JDBCGet.getconn();
			stmt = conn.createStatement();
			String sql = "select * from user where name = '"+name+"'";
			rs = stmt.executeQuery(sql);
			User user = new User();
			if(rs.next()){
				user.setPassword(rs.getString("password"));
				user.setCard(rs.getInt("grade"));
			}
			JDBCGet.closek(conn, stmt, rs);
			return user;
		}catch(Exception e){
			e.printStackTrace();
		}
		return null;
	}
	
	//��ѯ������Ϣ������ʱ��ѯ�����û���ͼ���ţ�
	public Record Return(String id){ 
		try{
			conn = JDBCGet.getconn();
			stmt = conn.createStatement();
			String sql = "select * from record where card = '"+id+"'";
			rs = stmt.executeQuery(sql);
			Record record = new Record();
			if(rs.next()){
				record.setBook_id(rs.getString("book_id"));
				record.setUsername(rs.getString("username"));
			}
			JDBCGet.closek(conn, stmt, rs);
			return record;
		}catch(Exception e){
			e.printStackTrace();
		}
		return null;
	}
	//��ѯ�鼮�������������߱�ţ�
	public Book Cha(String name){               
		Book book = new Book();
		try{
			conn = JDBCGet.getconn();
			stmt = conn.createStatement();
			String sql = "select * from book where name = '"+name+"' or id ='"+name+"'";
			//�����ѯ���Ľ��  ResultSet
			rs = stmt.executeQuery(sql);
			while(rs.next()){
				book.setBookid(rs.getString("id"));	
				book.setBookName(rs.getString("name"));
				book.setBookAuthor(rs.getString("author"));
				book.setBookNumber(rs.getInt("num"));
			}
			JDBCGet.closek(conn, stmt, rs);
			return book;
		}catch(Exception e){
			e.printStackTrace();
		}
		return null;
	}
	//��ѯȫ���鼮ͨ��List����
	public List<Book> Cha(){               
		try{
			List<Book> list = new ArrayList<Book>();
			conn = JDBCGet.getconn();
			stmt = conn.createStatement();
			String sql = "select * from book";
			rs = stmt.executeQuery(sql);
			//�����ѯ���Ľ��  ResultSet
			while(rs.next()){
				Book book = new Book();
				book.setBookid(rs.getString("id"));	
				book.setBookName(rs.getString("name"));
				book.setBookAuthor(rs.getString("author"));
				book.setBookNumber(rs.getInt("num"));
				list.add(book);
			}
			JDBCGet.closek(conn, stmt, rs);
			return list;
		}catch(Exception e){
			e.printStackTrace();
		}
		return null;
	}
}
