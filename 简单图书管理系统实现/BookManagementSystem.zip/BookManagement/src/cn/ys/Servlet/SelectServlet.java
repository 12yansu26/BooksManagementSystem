package cn.ys.Servlet;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import book.dao.ZSGC;
import book.vo.Book;

public class SelectServlet extends HttpServlet {

	/**
	 * ��ѯͼ��
	 */
	private static final long serialVersionUID = 1L;
	public void destroy() {
		super.destroy();
	}
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String name = request.getParameter("name");
		ZSGC zsgc = new ZSGC();
		Book book = zsgc.Cha(name);
		if(book==null){
			PrintWriter out  = response.getWriter();
			out.write("��Ǹû���Ȿ��");
			return ;
		}
		request.getSession().setAttribute("book", book);
		request.getRequestDispatcher("/showone.jsp").forward(request,response);
	}
	public void doPost(HttpServletRequest request, HttpServletResponse response)			throws ServletException, IOException {
		doGet(request,response);
	}
	public void init() throws ServletException {
	}
}
