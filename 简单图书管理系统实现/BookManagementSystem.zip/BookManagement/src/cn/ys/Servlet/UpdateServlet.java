package cn.ys.Servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import book.dao.ZSGC;
public class UpdateServlet extends HttpServlet {
	/**
	 * ����ͼ��(����Ա����)
	 */
	private static final long serialVersionUID = 1L;
	public void destroy() {
		super.destroy();
	}
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		//��ȡ����ͼ������Ҫ���µ�ͼ������
		String id = request.getParameter("id");
		String name = request.getParameter("name");
		ZSGC zsgc = new ZSGC();
		boolean b = zsgc.Gai(id, name);
		if(b){
			request.setAttribute("success", "�޸ĳɹ�������");
			request.getRequestDispatcher("/success.jsp").forward(request, response);
		}else{
			request.setAttribute("success", "�޸�ʧ�ܣ�����");
			request.getRequestDispatcher("/success.jsp").forward(request, response);
		}
	}
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request,response);
	}
	public void init() throws ServletException {
		
	}
}
