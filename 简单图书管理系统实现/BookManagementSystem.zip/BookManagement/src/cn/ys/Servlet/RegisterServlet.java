package cn.ys.Servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import book.dao.ZSGC;
import book.vo.User;

public class RegisterServlet extends HttpServlet {
	/**
	 * ע��
	 */
	private static final long serialVersionUID = 1L;
	public void destroy() {
		super.destroy();
	}
	
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		//��ȡ�û�������ǳơ����롢ȷ�ϵ�����
		String name = request.getParameter("name");
		String password = request.getParameter("password");
		String password1 = request.getParameter("password1");
		ZSGC zsgc = new ZSGC();
		User user = zsgc.login(name);
		//��ѯ�û��Ƿ����
		if(user.getPassword()!=null){
			request.setAttribute("success", "�û����Դ���");
			request.getRequestDispatcher("/success.jsp").forward(request, response);
		}else if(password.equals(password1)){
			user.setName(name);
			user.setPassword(password);
			
			//�����û�����Ϊ��0��
			user.setCard(0);
			boolean b = zsgc.Zeng(user);
			//�ж��Ƿ����ӳɹ�
			if(b){
				request.setAttribute("success", "ע��ɹ�");
				request.getRequestDispatcher("/success.jsp").forward(request, response);
			}else{
				request.setAttribute("success", "ע��ʧ��");
				request.getRequestDispatcher("/success.jsp").forward(request, response);
			}
		}else{
			request.setAttribute("success", "�������");
			request.getRequestDispatcher("/success.jsp").forward(request, response);
		}
	}
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request,response);
	}
	public void init() throws ServletException {
		
	}
}
