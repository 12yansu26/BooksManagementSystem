package cn.ys.Servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import book.dao.ZSGC;
import book.vo.Book;

public class Showservlet extends HttpServlet {

	/**
	 * ��ѯ����ͼ��
	 */
	private static final long serialVersionUID = 1L;
	public void destroy() {
		super.destroy();
	}

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		//����dao�����ʵ�����ݿ����
		ZSGC zsgc = new ZSGC();
		//��ȡ����ֵ����List��
		List<Book> list = zsgc.Cha();
		//������ͼ����Ϣ�ŵ�Session��
		request.getSession().setAttribute("list", list);
//		ת����showallbooks.jsp
		request.getRequestDispatcher("/showallbooks.jsp").forward(request,response);
	}
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request,response);
	}
	public void init() throws ServletException {
	}
}
