package cn.ys.Servlet;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import book.dao.ZSGC;
import book.vo.Book;
import book.vo.Record;
public class ReturnServlelt extends HttpServlet {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public void destroy() {
		super.destroy();
	}
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		ZSGC zsgc = new ZSGC();
		String id = request.getParameter("id");
		String name = request.getParameter("name");
		Record record = zsgc.Return(id);
		if(record.getUsername().equals(name)){
			record.setCard(id);
			Book book = zsgc.Cha(record.getBook_id());
			boolean b = zsgc.Shan(record);
			if(b){
				int num = book.getBookNumber();
				zsgc.Gai(num+1, book.getBookid());
				request.setAttribute("success", "����ɹ�������");
				request.getRequestDispatcher("/success.jsp").forward(request, response);
			}else{
				request.setAttribute("success", "����ʧ�ܣ�����");
				request.getRequestDispatcher("/success.jsp").forward(request, response);
			}
		}
	}
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request,response);
	}
	public void init() throws ServletException {
		
	}
}
