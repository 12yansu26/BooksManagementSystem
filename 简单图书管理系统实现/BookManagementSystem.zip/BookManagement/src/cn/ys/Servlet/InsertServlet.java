package cn.ys.Servlet;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import book.dao.ZSGC;
import book.vo.Book;

public class InsertServlet extends HttpServlet {

	/**
	 * ����ͼ�飨����Ա���ܣ�
	 */
	private static final long serialVersionUID = 1L;
	public void destroy() {
		super.destroy();
	}
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		Book book = new Book();
		//��ȡͼ����Ϣ
		book.setBookid(request.getParameter("id"));	
		book.setBookName(request.getParameter("name"));
		book.setBookAuthor(request.getParameter("author"));
		String num = request.getParameter("num");
		//ͨ��Integer��Stringת��Ϊint
		book.setBookNumber(Integer.parseInt(num));
		ZSGC zsgc = new ZSGC();
		boolean a = zsgc.Zeng(book);
		//�ж��Ƿ����ӳɹ�
		if(a){
			request.setAttribute("success", "���ӳɹ�");
			request.getRequestDispatcher("/success.jsp").forward(request,response);
		}else{
			request.setAttribute("success", "���ӳɹ�");
			request.getRequestDispatcher("/success.jsp").forward(request,response);
		}
	}
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request,response);
	}
	public void init() throws ServletException {
	}

}
